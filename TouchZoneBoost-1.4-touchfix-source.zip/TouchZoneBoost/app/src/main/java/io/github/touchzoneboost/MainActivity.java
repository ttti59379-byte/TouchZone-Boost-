package io.github.touchzoneboost;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.ComponentName;

import rikka.shizuku.Shizuku;

public final class MainActivity extends Activity {
    private LinearLayout content;
    private TextView status, shizukuStatus;
    private Button zoneButton, stopButton, freeFireButton;
    private final int[] colors = { Color.BLACK, Color.WHITE, Color.CYAN, 0xffaa83ff, 0xffff5252, 0xff70e06d };
    private final String[] colorNames = { "Чёрная", "Белая", "Голубая", "Фиолетовая", "Красная", "Зелёная" };

    private final Shizuku.OnRequestPermissionResultListener permissionResult = (code, result) -> {
        runOnUiThread(this::refreshStatus);
    };
    private final Shizuku.OnBinderReceivedListener binderReceived = () -> runOnUiThread(this::refreshStatus);
    private final Shizuku.OnBinderDeadListener binderDead = () -> runOnUiThread(this::refreshStatus);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff101015);
        getWindow().setNavigationBarColor(0xff101015);
        makeUi();
        try {
            Shizuku.addRequestPermissionResultListener(permissionResult);
            Shizuku.addBinderReceivedListener(binderReceived);
            Shizuku.addBinderDeadListener(binderDead);
        } catch (Throwable ignored) { }
    }
    private int dp(float value) {return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        return d;
    }
    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setPadding(0,dp(9),0,dp(7));
        return t;
    }
    private void add(TextView t) {content.addView(t);}
    private Button button(String s) {
        Button b = new Button(this);
        b.setAllCaps(false); b.setText(s); b.setTextSize(15);
        b.setTextColor(Color.WHITE); b.setBackground(bg(0xff37324d,13));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,dp(52));
        lp.setMargins(0,dp(5),0,dp(5)); content.addView(b,lp);
        return b;
    }
    private String seekValue(String key, int value, String unit) {
        if ("sens_x".equals(key) || "sens_y".equals(key)) {
            return String.format(java.util.Locale.US, "%.2f×", value / 100.0);
        }
        return value + unit;
    }
    private void seek(String title, String key, int min, int max, int value, String unit) {
        TextView heading = text("",16,0xffe6e2ef);
        content.addView(heading);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max-min);
        int val = Prefs.get(this).getInt(key,value);
        bar.setProgress(Math.min(max,Math.max(min,val))-min);
        heading.setText(title+": "+seekValue(key,val,unit));
        content.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int v=progress+min;
                heading.setText(title+": "+seekValue(key,v,unit));
                if (fromUser) { Prefs.get(MainActivity.this).edit().putInt(key,v).apply(); TouchService.refresh(); }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
    }
    private void makeUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xff101015);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22),dp(22),dp(22),dp(38));
        scroll.addView(content); setContentView(scroll);

        TextView title=text("TouchZone Boost",27,0xffac9aff);
        title.setTypeface(null,Typeface.BOLD); add(title);
        add(text("Зона усиления жестов • Android 8.0+",13,0xffb5b1bd));
        status=text("",15,0xffd5d4e3); add(status);

        freeFireButton=button("▶  Запустить Free Fire");
        freeFireButton.setBackground(bg(0xffbe4e26,13));
        freeFireButton.setOnClickListener(v -> launchFreeFire());
        add(text("Запуск обычного Free Fire. Если установлен только Free Fire MAX, откроется он. Активная зона останется включённой поверх игры.",13,0xffb5b1bd));

        zoneButton=button("Выбрать и переместить область");
        zoneButton.setOnClickListener(v -> {
            if (!hasAccessibility()) {
                new AlertDialog.Builder(this)
                    .setTitle("Разрешите специальные возможности")
                    .setMessage("В списке установленных служб найдите «TouchZone Boost — управление областью» и включите её. Затем вернитесь в приложение и повторите действие.")
                    .setPositiveButton("Открыть настройки",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                    .setNegativeButton("Отмена",null).show();
                return;
            }
            Prefs.get(this).edit().putBoolean("active",true).putBoolean("editing",true).apply();
            TouchService.refresh();
            new AlertDialog.Builder(this)
                .setTitle("Режим редактирования")
                .setMessage("Перетащите рамку в нужное место. Нижний правый угол меняет размер. Кнопка «✓ Сохранить» закрепит область. Можно открыть игру, пока рамка редактируется.")
                .setPositiveButton("Понятно",null).show();
        });
        stopButton=button("Отключить область");
        stopButton.setOnClickListener(v -> {
            Prefs.get(this).edit().putBoolean("active",false).putBoolean("editing",false).apply();
            TouchService.refresh(); refreshStatus();
        });

        add(text("Режим касаний",20,0xffac9aff));
        final String[] modeNames = {
            "Без задержки — прямые касания (для игры)",
            "Усиленный свайп до 10× — с задержкой",
            "Быстрый тап — без удержания и движения"
        };
        Button modeButton=button("Режим: "+modeNames[Prefs.inputMode(this)]);
        modeButton.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Выберите режим")
            .setSingleChoiceItems(modeNames,Prefs.inputMode(this),(dialog,which)-> {
                Prefs.get(this).edit().putInt("input_mode",which).apply();
                modeButton.setText("Режим: "+modeNames[which]);
                TouchService.refresh();
                dialog.dismiss();
            }).setNegativeButton("Отмена",null).show());
        add(text("Для Free Fire и движения прицела выбирайте «Без задержки»: пальцы, свайпы, удержание и мультитач проходят прямо в игру. В этом режиме множители X/Y не применяются. «Усиленный свайп» до 10× ждёт отпускания пальца; «Быстрый тап» подходит только для одиночных кнопок и не передаёт движения.",13,0xffb5b1bd));
        seek("Длительность быстрого тапа", "tap_ms", 16,100,32," мс");

        add(text("Чувствительность внутри области",20,0xffac9aff));
        add(text("0.50×–10.00× работает только при «Усиленный свайп»: он воспроизводится после завершения реального жеста. В режиме «Без задержки» чувствительность не меняется, но джойстик и прицел реагируют на каждый MOVE сразу.",13,0xffb5b1bd));
        seek("Ось X", "sens_x", 50,1000,150," %");
        seek("Ось Y", "sens_y", 50,1000,150," %");
        seek("Скорость воспроизведения", "speed", 35,150,100," %");

        add(text("Внешний вид зоны",20,0xffac9aff));
        Button colorButton=button("Цвет обводки");
        colorButton.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Выберите цвет рамки")
                .setItems(colorNames,(d,which)-> {
                    Prefs.get(this).edit().putInt("stroke",colors[which]).apply(); TouchService.refresh();
                }).show());
        seek("Заполнение цветом", "fill_alpha",0,55,0," %");
        add(text("При значении 0% кнопка полностью прозрачна с видимой обводкой.",13,0xffb5b1bd));

        add(text("Подключение Shizuku",20,0xffac9aff));
        shizukuStatus=text("Проверка Shizuku…",14,0xffd5d4e3); add(shizukuStatus);
        Button shizukuButton=button("Запросить доступ Shizuku");
        shizukuButton.setOnClickListener(v -> {
            try {
                if (!Shizuku.pingBinder()) {
                    new AlertDialog.Builder(this).setMessage("Shizuku не запущен. Сначала запустите его в приложении Shizuku через отладку по Wi-Fi.").setPositiveButton("OK",null).show();
                } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                    refreshStatus();
                } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                    new AlertDialog.Builder(this).setMessage("Разрешите доступ для TouchZone Boost в настройках Shizuku.").setPositiveButton("OK",null).show();
                } else Shizuku.requestPermission(123);
            } catch(Throwable e) { shizukuStatus.setText("Ошибка подключения: "+e.getClass().getSimpleName()); }
        });
        add(text("Shizuku здесь используется для проверки связи и авторизации. Жесты передаются через системную службу специальных возможностей, а не через Shizuku. Это не драйвер сенсора и не разгон частоты касаний.",13,0xffb5b1bd));
        add(text("Исправление 1.4: «Без задержки» теперь выбран по умолчанию и автоматически заменяет старый быстрый режим после обновления. Это устраняет захват касаний и блокировку движения. Android не позволяет этой схеме одновременно передавать настоящие движения без задержки и увеличивать их в 10×.",13,0xffffb29b));
        refreshStatus();
    }
    /** Запуск игры через штатный Android launcher intent. Не требует Shizuku или спецправ. */
    private void launchFreeFire() {
        final String[] packages = { "com.dts.freefireth", "com.dts.freefiremax" };
        PackageManager pm = getPackageManager();
        for (String packageName : packages) {
            Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
            if (launchIntent == null) continue;
            try {
                // Перед выходом из интерфейса передать службе текущие настройки области.
                TouchService.refresh();
                startActivity(launchIntent);
                return;
            } catch (android.content.ActivityNotFoundException | SecurityException ignored) {
                // При недоступном launcher intent попробовать вторую установленную версию.
            }
        }
        new AlertDialog.Builder(this)
            .setTitle("Free Fire не найден")
            .setMessage("Установите Free Fire или Free Fire MAX. Приложение запустит игру, когда она будет установлена на этом телефоне.")
            .setPositiveButton("Понятно", null)
            .show();
    }

    private boolean hasAccessibility() {
        String enabled=Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        String target = new ComponentName(this, TouchService.class).flattenToString();
        android.text.TextUtils.SimpleStringSplitter splitter = new android.text.TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        for (String part: splitter) if (part.equalsIgnoreCase(target)) return true;
        return false;
    }
    private void refreshStatus() {
        if (status == null) return;
        boolean enabled=hasAccessibility();
        status.setText("Спецвозможности: "+(enabled?"включены":"выключены")+"\nЗона: "+(Prefs.active(this)?"активна":"выключена"));
        if (shizukuStatus == null) return;
        try {
            if (!Shizuku.pingBinder()) shizukuStatus.setText("Shizuku: не запущен");
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED)
                shizukuStatus.setText("Shizuku: подключён и разрешён");
            else shizukuStatus.setText("Shizuku: запущен, ждёт разрешения");
        } catch(Throwable e) { shizukuStatus.setText("Shizuku: недоступен"); }
    }
    @Override protected void onResume() {super.onResume(); if (status != null) refreshStatus();}
    @Override protected void onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permissionResult);
            Shizuku.removeBinderReceivedListener(binderReceived);
            Shizuku.removeBinderDeadListener(binderDead);
        } catch (Throwable ignored) { }
        super.onDestroy();
    }
}
