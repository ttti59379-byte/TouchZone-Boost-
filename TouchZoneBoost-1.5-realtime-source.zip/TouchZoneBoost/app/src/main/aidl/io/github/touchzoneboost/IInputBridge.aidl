package io.github.touchzoneboost;

interface IInputBridge {
    boolean start(int left, int top, int width, int height,
                  int screenWidth, int screenHeight, float scaleX, float scaleY);
    void update(int left, int top, int width, int height,
                int screenWidth, int screenHeight, float scaleX, float scaleY);
    void stop();
    boolean isActive();
    String getLastError();
}
