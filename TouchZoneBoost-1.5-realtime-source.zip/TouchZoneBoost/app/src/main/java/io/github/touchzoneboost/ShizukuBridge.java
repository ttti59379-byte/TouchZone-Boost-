package io.github.touchzoneboost;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

/** Binds the shell UserService. Never enables touch capture outside Free Fire. */
public final class ShizukuBridge {
    private static volatile IInputBridge remote;
    private static volatile String error="";
    private static volatile boolean binding;
    private static Context context;
    private static final ExecutorService commands=Executors.newSingleThreadExecutor();
    private static final Shizuku.OnBinderReceivedListener binderReceived=()->refresh(context);
    private static final Shizuku.OnBinderDeadListener binderDead=()->{
        remote=null; binding=false; error="Shizuku отключён";
    };
    private static boolean listeners;
    private static final ServiceConnection connection=new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name,IBinder binder) {
            remote=IInputBridge.Stub.asInterface(binder);
            binding=false;
            refresh(context);
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            remote=null; binding=false; error="Служба ввода отключилась";
        }
    };
    private static Shizuku.UserServiceArgs args(Context c) {
        return new Shizuku.UserServiceArgs(
            new ComponentName(c.getPackageName(),InputMonitorService.class.getName()))
            .daemon(false).processNameSuffix("touchzone_input").version(2);
    }
    public static synchronized void init(Context c) {
        if(c==null)return;
        context=c.getApplicationContext();
        if(!listeners) {
            try {
                Shizuku.addBinderReceivedListener(binderReceived);
                Shizuku.addBinderDeadListener(binderDead);
                listeners=true;
            } catch(Throwable e) {error=e.getClass().getSimpleName();}
        }
    }
    public static synchronized void connect(Context c) {
        if(c==null)return;
        init(c);
        if(remote!=null||binding)return;
        try {
            if(!Shizuku.pingBinder()) {error="Запустите Shizuku";return;}
            if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED) {
                error="Предоставьте доступ Shizuku";return;
            }
            binding=true;
            Shizuku.bindUserService(args(c),connection);
            error="";
        } catch(Throwable e) {
            binding=false; error="Привязка Shizuku: "+e.getClass().getSimpleName();
        }
    }
    public static void refresh(Context c) {
        if(c==null)return;
        init(c);
        commands.execute(()->apply(c.getApplicationContext()));
    }
    private static void apply(Context c) {
        if(c==null)return;
        boolean shouldRun=Prefs.active(c) && !Prefs.editing(c) && Prefs.inputMode(c)==1
            && Prefs.get(c).getBoolean("game_focus",false);
        IInputBridge svc=remote;
        if(!shouldRun) {
            if(svc!=null) try {svc.stop();}catch(RemoteException e){remote=null;}
            return;
        }
        if(svc==null) {
            // Shizuku.bindUserService delivers its result asynchronously.
            connect(c);
            return;
        }
        try {
            WindowManager wm=(WindowManager)c.getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics dm=new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            int w=Prefs.getBox(c,"w",Math.round(180*dm.density));
            int h=Prefs.getBox(c,"h",Math.round(155*dm.density));
            int x=Prefs.getBox(c,"x",(dm.widthPixels-w)/2);
            int y=Prefs.getBox(c,"y",(dm.heightPixels-h)/2);
            w=Math.max(1,Math.min(w,dm.widthPixels));
            h=Math.max(1,Math.min(h,dm.heightPixels));
            x=Math.max(0,Math.min(x,dm.widthPixels-w));
            y=Math.max(0,Math.min(y,dm.heightPixels-h));
            if(!svc.isActive()) {
                if(!svc.start(x,y,w,h,dm.widthPixels,dm.heightPixels,Prefs.dx(c),Prefs.dy(c))) {
                    error=svc.getLastError();
                } else error="";
            } else {
                svc.update(x,y,w,h,dm.widthPixels,dm.heightPixels,Prefs.dx(c),Prefs.dy(c));
            }
        } catch(Throwable e) {
            error="Ошибка ввода: "+e.getClass().getSimpleName()+" — "+e.getMessage();
            if(svc!=null)try{svc.stop();}catch(Exception ignored){}
        }
    }
    public static void stop(Context c) {
        if(c==null)return;
        Prefs.get(c).edit().putBoolean("game_focus",false).apply();
        IInputBridge svc=remote;
        if(svc!=null) commands.execute(()->{try{svc.stop();}catch(Exception ignored){}});
    }
    public static String status() {
        try {
            if(!Shizuku.pingBinder())return "Shizuku не запущен — обычные касания";
            if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED)
                return "Нет разрешения Shizuku — обычные касания";
            IInputBridge svc=remote;
            if(svc==null)return "Shizuku подключается — обычные касания";
            String err=svc.getLastError();
            if(err!=null&&!err.isEmpty())return err+" (обычные касания)";
            if(!error.isEmpty())return error;
            return svc.isActive()?"Усиление включено через Shizuku":"Готово; усиление только в Free Fire";
        } catch(Throwable e) {return "Shizuku недоступен — обычные касания";}
    }
    private ShizukuBridge() {}
}
