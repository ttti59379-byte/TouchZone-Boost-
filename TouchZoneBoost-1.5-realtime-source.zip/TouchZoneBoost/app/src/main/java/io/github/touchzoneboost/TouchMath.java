package io.github.touchzoneboost;

/** Pure-Java math, so scaling can be tested without an Android device. */
public final class TouchMath {
    private TouchMath() {}
    public static boolean inside(float x,float y,int left,int top,int right,int bottom) {
        return x>=left && x<right && y>=top && y<bottom;
    }
    public static float scaled(float origin,float value,float factor,int extent) {
        return Math.max(0,Math.min(extent-1,origin+(value-origin)*factor));
    }
}
