package io.github.touchzoneboost;

import android.accessibilityservice.AccessibilityService;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * v1.5: the overlay NEVER consumes game touches.
 * Editing is the only time it becomes touchable. Real-time transforms are done
 * in the Shizuku InputMonitor UserService, not by dispatchGesture().
 */
public final class TouchService extends AccessibilityService {
    private static TouchService instance;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private ZoneView zone;
    private WindowManager.LayoutParams zoneParams;
    private LinearLayout toolbar;
    private int volumePresses;
    private long previousVolumeDown;

    static void refresh() {
        TouchService s=instance;
        if(s!=null) s.main.post(s::applySettings);
    }
    private int dp(float x) {
        return (int)(x*getResources().getDisplayMetrics().density+0.5f);
    }
    private int clamp(int a,int low,int hi) {return Math.max(low,Math.min(a,hi));}
    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance=this;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        Prefs.get(this).edit().putBoolean("game_focus",false).apply();
        ShizukuBridge.init(this);
        ShizukuBridge.connect(this);
        applySettings();
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        int type=e.getEventType();
        if(type!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
           type!=AccessibilityEvent.TYPE_WINDOWS_CHANGED)return;
        CharSequence name=e.getPackageName();
        if(name==null)return;
        String pkg=name.toString();
        // Input capture is NEVER active on the home screen, Shizuku permission
        // screens, system settings, or any unrelated app.
        boolean game=pkg.equals("com.dts.freefireth") || pkg.equals("com.dts.freefiremax");
        boolean previous=Prefs.get(this).getBoolean("game_focus",false);
        if(game!=previous) {
            Prefs.get(this).edit().putBoolean("game_focus",game).apply();
            ShizukuBridge.refresh(this);
        }
    }
    @Override public boolean onKeyEvent(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.KEYCODE_VOLUME_DOWN && e.getAction()==KeyEvent.ACTION_DOWN
           && e.getRepeatCount()==0) {
            long now=SystemClock.uptimeMillis();
            volumePresses = now-previousVolumeDown<=1200 ? volumePresses+1 : 1;
            previousVolumeDown=now;
            if(volumePresses>=3) {
                volumePresses=0;
                Prefs.get(this).edit().putBoolean("input_mode_v15_stop",true)
                   .putBoolean("active",false).putBoolean("editing",false).apply();
                ShizukuBridge.stop(this);
                applySettings();
            }
        }
        return false; // Volume keys must keep working normally.
    }
    @Override public void onInterrupt() {ShizukuBridge.stop(this);}
    @Override public void onDestroy() {
        if(instance==this)instance=null;
        Prefs.get(this).edit().putBoolean("game_focus",false).apply();
        ShizukuBridge.stop(this);
        destroyViews();
        main.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        ShizukuBridge.stop(this);
        main.postDelayed(()->{destroyViews();applySettings();},200);
    }
    private int screenWidth() {
        DisplayMetrics m=new DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);return m.widthPixels;
    }
    private int screenHeight() {
        DisplayMetrics m=new DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);return m.heightPixels;
    }
    private void destroyViews() {
        removeToolbar();
        if(zone!=null && wm!=null)try {wm.removeViewImmediate(zone);}catch(Exception ignored){}
        zone=null;zoneParams=null;
    }
    private void removeToolbar() {
        if(toolbar!=null && wm!=null)try {wm.removeViewImmediate(toolbar);}catch(Exception ignored){}
        toolbar=null;
    }
    private void applySettings() {
        if(wm==null)return;
        ShizukuBridge.refresh(this);
        if(!Prefs.active(this)) {destroyViews();return;}
        if(zone==null) {
            int sw=screenWidth(),sh=screenHeight();
            int w=clamp(Prefs.getBox(this,"w",dp(180)),dp(55),sw);
            int h=clamp(Prefs.getBox(this,"h",dp(155)),dp(55),sh);
            int x=clamp(Prefs.getBox(this,"x",(sw-w)/2),0,Math.max(0,sw-w));
            int y=clamp(Prefs.getBox(this,"y",(sh-h)/2),0,Math.max(0,sh-h));
            int flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            // The flag is present BEFORE adding the overlay. There is no
            // momentary tap interception during a normal game session.
            if(!Prefs.editing(this))flags|=WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            zoneParams=new WindowManager.LayoutParams(w,h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                flags,PixelFormat.TRANSLUCENT);
            zoneParams.gravity=Gravity.TOP|Gravity.LEFT;
            zoneParams.x=x;zoneParams.y=y;
            zone=new ZoneView();
            try {wm.addView(zone,zoneParams);}
            catch(Exception ex){zone=null;zoneParams=null;return;}
        }
        setPassThrough(!Prefs.editing(this));
        zone.invalidate();
        if(Prefs.editing(this))showToolbar();else removeToolbar();
    }
    private void setPassThrough(boolean passthrough) {
        if(zone==null || zoneParams==null)return;
        boolean old=(zoneParams.flags&WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)!=0;
        if(old==passthrough)return;
        if(passthrough)zoneParams.flags|=WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else zoneParams.flags&=~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try{wm.updateViewLayout(zone,zoneParams);}catch(Exception ignored){}
    }
    private void changeBox(int x,int y,int w,int h) {
        if(zone==null||zoneParams==null)return;
        int sw=screenWidth(),sh=screenHeight();
        w=clamp(w,dp(55),sw);h=clamp(h,dp(55),sh);
        zoneParams.x=clamp(x,0,Math.max(0,sw-w));
        zoneParams.y=clamp(y,0,Math.max(0,sh-h));
        zoneParams.width=w;zoneParams.height=h;
        try{wm.updateViewLayout(zone,zoneParams);}catch(Exception ignored){}
    }
    private void saveEditing() {
        if(zoneParams==null)return;
        Prefs.saveBox(this,zoneParams.x,zoneParams.y,zoneParams.width,zoneParams.height);
        Prefs.get(this).edit().putBoolean("editing",false).apply();
        applySettings();
    }
    private void showToolbar() {
        if(toolbar!=null)return;
        toolbar=new LinearLayout(this);
        toolbar.setBackgroundColor(0xdd222233);
        Button save=new Button(this);
        save.setText("✓ Сохранить");save.setAllCaps(false);save.setTextColor(Color.WHITE);
        save.setOnClickListener(v->saveEditing());
        toolbar.addView(save,new LinearLayout.LayoutParams(dp(158),dp(54)));
        Button hide=new Button(this);
        hide.setText("× Скрыть");hide.setAllCaps(false);hide.setTextColor(Color.WHITE);
        hide.setOnClickListener(v->{
            Prefs.get(this).edit().putBoolean("active",false).putBoolean("editing",false).apply();
            applySettings();
        });
        toolbar.addView(hide,new LinearLayout.LayoutParams(dp(115),dp(54)));
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(-2,-2,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.LEFT;
        p.x=dp(8);p.y=dp(40);
        try{wm.addView(toolbar,p);}catch(Exception ex){toolbar=null;}
    }
    private final class ZoneView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean resize,move;
        private float downX,downY;
        private int initialX,initialY,initialW,initialH;
        ZoneView() {super(TouchService.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            boolean edit=Prefs.editing(TouchService.this);
            int color=Prefs.stroke(TouchService.this);
            int fill=Prefs.alpha(TouchService.this);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor((Math.round(fill*255f/100f)<<24)|(color&0x00ffffff));
            canvas.drawRoundRect(dp(3),dp(3),getWidth()-dp(3),getHeight()-dp(3),dp(15),dp(15),paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(edit?3:2));paint.setColor(color);
            canvas.drawRoundRect(dp(3),dp(3),getWidth()-dp(3),getHeight()-dp(3),dp(15),dp(15),paint);
            if(edit) {
                paint.setStyle(Paint.Style.FILL);paint.setColor(0xdd8066f3);
                canvas.drawCircle(getWidth()-dp(17),getHeight()-dp(17),dp(14),paint);
                paint.setColor(Color.WHITE);paint.setTextAlign(Paint.Align.CENTER);
                paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(dp(12));
                canvas.drawText("ПЕРЕТАЩИТЕ",getWidth()/2f,getHeight()/2f,paint);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            // Only receives events during editing. Otherwise the entire window
            // has FLAG_NOT_TOUCHABLE, even if realtime amplification is enabled.
            if(!Prefs.editing(TouchService.this)||zoneParams==null)return false;
            int action=e.getActionMasked();
            if(action==MotionEvent.ACTION_DOWN) {
                downX=e.getRawX();downY=e.getRawY();
                initialX=zoneParams.x;initialY=zoneParams.y;
                initialW=zoneParams.width;initialH=zoneParams.height;
                resize=e.getX()>getWidth()-dp(42)&&e.getY()>getHeight()-dp(42);
                move=!resize;return true;
            }
            if(action==MotionEvent.ACTION_MOVE && (resize||move)) {
                int dx=Math.round(e.getRawX()-downX);
                int dy=Math.round(e.getRawY()-downY);
                if(resize)changeBox(initialX,initialY,initialW+dx,initialH+dy);
                else changeBox(initialX+dx,initialY+dy,initialW,initialH);
                return true;
            }
            if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL) {
                resize=false;move=false;
            }
            return true;
        }
    }
}
