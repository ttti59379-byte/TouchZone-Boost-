import io.github.touchzoneboost.TouchMath;
public class TouchMathCheck {
    private static void check(boolean ok) {if(!ok)throw new AssertionError("touch coordinate test failed");}
    public static void main(String[] args) {
        check(TouchMath.inside(10,10,10,10,40,40));
        check(!TouchMath.inside(40,10,10,10,40,40));
        check(!TouchMath.inside(0,10,10,10,40,40));
        check(TouchMath.scaled(200,205,10,500)==250);
        check(TouchMath.scaled(200,180,10,500)==0);
        check(TouchMath.scaled(100,200,10,500)==499);
        check(TouchMath.scaled(100,200,1,500)==200);
        check(TouchMath.scaled(100,200,.5f,500)==150);
        System.out.println("TouchMath OK");
    }
}
