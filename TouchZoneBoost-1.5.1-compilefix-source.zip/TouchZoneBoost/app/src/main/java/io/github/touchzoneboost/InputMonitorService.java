package io.github.touchzoneboost;

import android.content.Context;
import android.hardware.input.InputManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.view.Display;
import android.view.InputChannel;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.InputEventReceiver;
import android.view.InputMonitor;
import android.view.MotionEvent;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Runs as a Shizuku UserService (shell UID, NOT the app UID).
 * Uses the hidden InputMonitor API only where the ROM allows it.
 * Until pilferPointers() is called for an in-zone ACTION_DOWN, the original
 * input stream passes to the game normally. Outside the zone nothing is pilfered.
 * Fail-closed: errors immediately DISABLE capture and dispose the monitor.
 */
public final class InputMonitorService extends IInputBridge.Stub {
    private static final int INJECT_ASYNC = 0;
    private static final int SYNTHETIC_EDGE_TAG = 0x40000000;
    private final HandlerThread thread = new HandlerThread("TouchZone-Input", Process.THREAD_PRIORITY_DISPLAY);
    private final Handler handler;
    private volatile boolean enabled;
    private volatile String lastError = "";
    private InputMonitor monitor;
    private InputEventReceiver receiver;
    private Object manager;
    private Method inject;
    private boolean captured;
    private long activeDownTime;
    // InputMonitor can also observe events we inject. Edge flags are the first
    // defense; a signature ring catches ROMs which strip custom edge flags.
    private final long[] recentSynthetic = new long[48];
    private int syntheticIndex;
    private static long signature(MotionEvent e) {
        long t=e.getEventTime();
        long down=e.getDownTime();
        // Timestamps usually resolve to milliseconds; mixing pointer count and
        // masked action separates DOWN / MOVE / POINTER_* / UP at the same time.
        return (t*1315423911L) ^ (down*2654435761L) ^
            ((long)e.getAction()<<48) ^ ((long)e.getPointerCount()<<56);
    }
    private boolean isEcho(MotionEvent e) {
        long sig=signature(e);
        for(long value:recentSynthetic) if(value==sig) return true;
        return false;
    }
    private final Map<Integer, float[]> starts = new HashMap<>();
    private volatile Config config = new Config(0, 0, 0, 0, 1, 1, 1f, 1f);

    public InputMonitorService() {
        thread.start();
        handler = new Handler(thread.getLooper());
    }
    public InputMonitorService(Context ignored) { this(); }

    private static final class Config {
        final int left, top, right, bottom, sw, sh;
        final float sx, sy;
        Config(int x, int y, int w, int h, int screenW, int screenH, float scaleX, float scaleY) {
            left=x; top=y; right=x+w; bottom=y+h;
            sw=Math.max(1,screenW); sh=Math.max(1,screenH);
            sx=Math.max(.5f,Math.min(10f,scaleX));
            sy=Math.max(.5f,Math.min(10f,scaleY));
        }
        boolean contains(float x, float y) {
            return TouchMath.inside(x,y,left,top,right,bottom);
        }
    }
    private static Config validate(int x,int y,int w,int h,int sw,int sh,float sx,float sy) {
        if(w<1||h<1||sw<1||sh<1||x<0||y<0||x>=sw||y>=sh ||
           !Float.isFinite(sx)||!Float.isFinite(sy)||sx<.5f||sy<.5f||sx>10f||sy>10f) {
            throw new IllegalArgumentException("Некорректные координаты зоны или множители");
        }
        return new Config(x,y,w,h,sw,sh,sx,sy);
    }

    @Override public boolean start(int x,int y,int w,int h,int sw,int sh,float sx,float sy) {
        try { config=validate(x,y,w,h,sw,sh,sx,sy); }
        catch(Exception e) {lastError=e.getMessage();return false;}
        if(enabled) return true;
        final CountDownLatch latch=new CountDownLatch(1);
        final AtomicBoolean started=new AtomicBoolean();
        handler.post(()->{
            try {started.set(startInternal());}
            finally {latch.countDown();}
        });
        try {
            if(!latch.await(1500,TimeUnit.MILLISECONDS)) {
                lastError="Время запуска InputMonitor истекло";
                enabled=false;
                handler.post(this::stopInternal);
                return false;
            }
        } catch(InterruptedException e) {
            Thread.currentThread().interrupt();
            lastError="Подключение прервано";
            enabled=false;
            handler.post(this::stopInternal);
            return false;
        }
        return started.get() && enabled;
    }
    @Override public void update(int x,int y,int w,int h,int sw,int sh,float sx,float sy) {
        try { config=validate(x,y,w,h,sw,sh,sx,sy); }
        catch(Exception e) {lastError=e.getMessage();stop();}
    }
    @Override public void stop() {
        enabled=false;
        handler.post(this::stopInternal);
    }
    @Override public boolean isActive() {return enabled;}
    @Override public String getLastError() {return lastError;}

    private boolean startInternal() {
        if(enabled) return true;
        stopInternal();
        lastError="";
        try {
            if(Process.myUid()!=2000 && Process.myUid()!=0)
                throw new SecurityException("Shizuku должен запустить службу с UID shell/root");
            // Shizuku UserService is exempt from normal app hidden-API limitations.
            Class<?> klass=Class.forName("android.hardware.input.InputManager");
            manager=klass.getDeclaredMethod("getInstance").invoke(null);
            Method monitorMethod=klass.getDeclaredMethod("monitorGestureInput",String.class,int.class);
            monitorMethod.setAccessible(true);
            inject=klass.getDeclaredMethod("injectInputEvent",InputEvent.class,int.class);
            inject.setAccessible(true);
            monitor=(InputMonitor)monitorMethod.invoke(manager,"TouchZoneBoost",Display.DEFAULT_DISPLAY);
            if(monitor==null) throw new IllegalStateException("InputMonitor отсутствует");
            InputChannel channel=monitor.getInputChannel();
            if(channel==null) throw new IllegalStateException("InputChannel отсутствует");
            receiver=new InputEventReceiver(channel,Looper.myLooper()) {
                @Override public void onInputEvent(InputEvent event) {
                    try {
                        if(enabled && event instanceof MotionEvent) handle((MotionEvent)event);
                    } catch(Throwable e) {
                        lastError="Ошибка ввода: "+e.getClass().getSimpleName()+" — "+e.getMessage();
                        enabled=false;
                        // Cleanup after returning the event to InputDispatcher.
                        handler.post(InputMonitorService.this::stopInternal);
                    } finally {finishInputEvent(event,true);}
                }
            };
            enabled=true;
            return true;
        } catch(Throwable e) {
            lastError="InputMonitor недоступен: "+e.getClass().getSimpleName()+" — "+e.getMessage();
            stopInternal();
            return false;
        }
    }
    private void stopInternal() {
        enabled=false;
        captured=false;
        starts.clear();
        java.util.Arrays.fill(recentSynthetic,0);
        syntheticIndex=0;
        if(receiver!=null) {try {receiver.dispose();}catch(Throwable ignored){} receiver=null;}
        if(monitor!=null) {try {monitor.dispose();}catch(Throwable ignored){} monitor=null;}
        manager=null;
        inject=null;
    }

    private void handle(MotionEvent event) throws Exception {
        if(!enabled) return;
        if((event.getSource() & InputDevice.SOURCE_TOUCHSCREEN)!=InputDevice.SOURCE_TOUCHSCREEN) return;
        if((event.getEdgeFlags() & SYNTHETIC_EDGE_TAG)!=0 || isEcho(event)) return;
        // The monitor was registered for Display.DEFAULT_DISPLAY in startInternal().
        // Do not call MotionEvent.getDisplayId() here: the compile-only Android 12
        // framework stubs bundled with this project do not expose that method.

        int action=event.getActionMasked();
        if(action==MotionEvent.ACTION_DOWN) {
            captured=false;
            starts.clear();
            Config c=config;
            if(!c.contains(event.getX(0),event.getY(0))) return;
            // Only an in-zone DOWN starts a fully pilfered gesture. If this call
            // fails, normal touches continue through the system unmodified.
            monitor.pilferPointers();
            captured=true;
            activeDownTime=event.getDownTime();
        }
        if(!captured) return;
        // Synthetically injected gestures can be observed by the monitor too.
        // The edge flag above prevents a feedback loop.
        if(event.getDownTime()!=activeDownTime) return;
        Config c=config;
        int count=event.getPointerCount();
        MotionEvent.PointerProperties[] props=new MotionEvent.PointerProperties[count];
        MotionEvent.PointerCoords[] coords=new MotionEvent.PointerCoords[count];
        for(int i=0;i<count;i++) {
            int id=event.getPointerId(i);
            float x=event.getX(i), y=event.getY(i);
            float[] origin=starts.get(id);
            if(origin==null) {
                origin=new float[]{x,y,c.contains(x,y)?1f:0f};
                starts.put(id,origin);
            }
            props[i]=new MotionEvent.PointerProperties();
            coords[i]=new MotionEvent.PointerCoords();
            event.getPointerProperties(i,props[i]);
            event.getPointerCoords(i,coords[i]);
            if(origin[2]!=0) {
                coords[i].x=TouchMath.scaled(origin[0],x,c.sx,c.sw);
                coords[i].y=TouchMath.scaled(origin[1],y,c.sy,c.sh);
            }
        }
        MotionEvent transformed=MotionEvent.obtain(event.getDownTime(),
            Math.max(event.getDownTime(),event.getEventTime()),
            event.getAction(),count,props,coords,event.getMetaState(),
            event.getButtonState(),event.getXPrecision(),event.getYPrecision(),
            event.getDeviceId(),event.getEdgeFlags()|SYNTHETIC_EDGE_TAG,
            event.getSource(),event.getFlags());
        try {
            recentSynthetic[syntheticIndex++ % recentSynthetic.length]=signature(transformed);
            Object result=inject.invoke(manager,transformed,INJECT_ASYNC);
            if(result instanceof Boolean && !((Boolean)result))
                throw new IllegalStateException("Инъекция касаний отклонена прошивкой");
        } finally {transformed.recycle();}
        if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL) {
            captured=false;
            starts.clear();
        } else if(action==MotionEvent.ACTION_POINTER_UP) {
            starts.remove(event.getPointerId(event.getActionIndex()));
        }
    }

    // Invoked by Shizuku when the user-service lifecycle ends.
    public void destroy() { stop(); thread.quitSafely(); }
}
