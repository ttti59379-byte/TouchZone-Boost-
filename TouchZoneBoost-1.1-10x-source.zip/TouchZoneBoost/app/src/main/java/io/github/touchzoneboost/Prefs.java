package io.github.touchzoneboost;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.content.res.Configuration;

final class Prefs {
    private static final String NAME = "touchzone_settings";
    static SharedPreferences get(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }
    static float dx(Context c) { return get(c).getInt("sens_x", 150) / 100f; }
    static float dy(Context c) { return get(c).getInt("sens_y", 150) / 100f; }
    static int stroke(Context c) { return get(c).getInt("stroke", Color.BLACK); }
    static int alpha(Context c) { return get(c).getInt("fill_alpha", 0); }
    static boolean active(Context c) { return get(c).getBoolean("active", false); }
    static boolean editing(Context c) { return get(c).getBoolean("editing", false); }
    static int speed(Context c) { return get(c).getInt("speed", 100); }
    static String orient(Context c) {
        return c.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? "land_" : "port_";
    }
    static void saveBox(Context c, int x, int y, int w, int h) {
        String p = orient(c);
        get(c).edit().putInt(p+"x",x).putInt(p+"y",y).putInt(p+"w",w).putInt(p+"h",h).apply();
    }
    static int getBox(Context c, String key, int fallback) {
        return get(c).getInt(orient(c)+key, fallback);
    }
    private Prefs() {}
}
