package io.github.touchzoneboost;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PointF;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.graphics.Typeface;

import java.util.ArrayList;
import java.util.List;

/** Accessibility overlay zone that replays completed gestures at scaled X/Y displacement. */
public final class TouchService extends AccessibilityService {
    private static TouchService instance;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private ZoneView zone;
    private WindowManager.LayoutParams zoneParams;
    private LinearLayout toolbar;
    private boolean injecting;

    static void refresh() {
        TouchService s = instance;
        if (s != null) s.main.post(s::applySettings);
    }
    private int dp(float a) { return (int)(a * getResources().getDisplayMetrics().density + 0.5f); }
    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance=this;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        applySettings();
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }
    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        main.postDelayed(() -> {destroyViews(); applySettings();}, 200);
    }
    @Override public void onDestroy() {
        if (instance==this) instance=null;
        destroyViews();
        main.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
    private void destroyViews() {
        if (wm==null) return;
        removeToolbar();
        if(zone!=null) {try {wm.removeViewImmediate(zone);} catch(Exception ignored) {} zone=null;}
        zoneParams=null;
        injecting=false;
    }
    private void removeToolbar() {
        if (toolbar!=null && wm!=null) {
            try {wm.removeViewImmediate(toolbar);} catch (Exception ignored) {}
            toolbar=null;
        }
    }
    private int screenWidth() {
        DisplayMetrics dm=new DisplayMetrics(); wm.getDefaultDisplay().getRealMetrics(dm); return dm.widthPixels;
    }
    private int screenHeight() {
        DisplayMetrics dm=new DisplayMetrics(); wm.getDefaultDisplay().getRealMetrics(dm); return dm.heightPixels;
    }
    private int clamp(int v,int low,int high) {return Math.max(low,Math.min(high,v));}
    private void applySettings() {
        if (wm==null) return;
        if (!Prefs.active(this)) {destroyViews(); return;}
        if (zone==null) {
            int screenW=screenWidth(), screenH=screenHeight();
            int w=Prefs.getBox(this,"w",dp(180)), h=Prefs.getBox(this,"h",dp(155));
            w=clamp(w,dp(55),screenW); h=clamp(h,dp(55),screenH);
            int x=Prefs.getBox(this,"x",(screenW-w)/2);
            int y=Prefs.getBox(this,"y",(screenH-h)/2);
            zoneParams = new WindowManager.LayoutParams(w,h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
            zoneParams.gravity=Gravity.TOP|Gravity.LEFT;
            zoneParams.x=clamp(x,0,Math.max(0,screenW-w));
            zoneParams.y=clamp(y,0,Math.max(0,screenH-h));
            zone=new ZoneView();
            try {wm.addView(zone,zoneParams);} catch (Exception e) { zone=null; zoneParams=null; return; }
        }
        // A touch-through window cannot observe gestures. Keep the small area touchable
        // until a completed gesture is available, then switch it briefly off for replay.
        if (!injecting) {
            zoneParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            try{wm.updateViewLayout(zone,zoneParams);}catch(Exception ignored){}
        }
        zone.invalidate();
        if (Prefs.editing(this)) showToolbar(); else removeToolbar();
    }
    private void showToolbar() {
        if(toolbar!=null) return;
        toolbar=new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setPadding(dp(4),dp(3),dp(4),dp(3));
        toolbar.setBackgroundColor(0xee212025);
        Button save=new Button(this);
        save.setAllCaps(false);save.setText("✓ Сохранить");save.setTextColor(Color.WHITE);
        save.setOnClickListener(v -> saveEditing());
        toolbar.addView(save,new LinearLayout.LayoutParams(dp(152),dp(52)));
        Button hide=new Button(this);
        hide.setAllCaps(false);hide.setText("× Скрыть");hide.setTextColor(Color.WHITE);
        hide.setOnClickListener(v -> {
            Prefs.get(this).edit().putBoolean("active",false).putBoolean("editing",false).apply();
            applySettings();
        });
        toolbar.addView(hide,new LinearLayout.LayoutParams(dp(127),dp(52)));
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(-2,-2,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.LEFT;
        p.x=dp(8);p.y=dp(40);
        try {wm.addView(toolbar,p);} catch(Exception ignored) {toolbar=null;}
    }
    private void saveEditing() {
        if(zoneParams==null) return;
        Prefs.saveBox(this,zoneParams.x,zoneParams.y,zoneParams.width,zoneParams.height);
        Prefs.get(this).edit().putBoolean("editing",false).apply();
        applySettings();
    }
    private void changeBox(int x,int y,int w,int h) {
        if(zone==null||zoneParams==null) return;
        int W=screenWidth(),H=screenHeight();
        w=clamp(w,dp(55),W);
        h=clamp(h,dp(55),H);
        zoneParams.width=w; zoneParams.height=h;
        zoneParams.x=clamp(x,0,Math.max(0,W-w));
        zoneParams.y=clamp(y,0,Math.max(0,H-h));
        try{wm.updateViewLayout(zone,zoneParams);}catch(Exception ignored){}
    }
    private void setPassThrough(boolean pass) {
        if(zone==null||zoneParams==null) return;
        if(pass) zoneParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else zoneParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try{wm.updateViewLayout(zone,zoneParams);}catch(Exception ignored){}
    }
    private void replay(List<PointF> raw,long elapsed) {
        if(zone==null||raw.size()==0) {injecting=false;return;}
        final float xscale=Prefs.dx(this), yscale=Prefs.dy(this);
        final float baseX=raw.get(0).x, baseY=raw.get(0).y;
        int screenW=screenWidth(), screenH=screenHeight();
        Path path=new Path();
        path.moveTo(clamp(Math.round(baseX),1,screenW-2),clamp(Math.round(baseY),1,screenH-2));
        boolean moved=false;
        for (int i=1;i<raw.size();i++) {
            PointF p=raw.get(i);
            float x=clamp(Math.round(baseX+(p.x-baseX)*xscale),1,screenW-2);
            float y=clamp(Math.round(baseY+(p.y-baseY)*yscale),1,screenH-2);
            if (Math.abs(p.x-baseX)+Math.abs(p.y-baseY)>dp(3)) moved=true;
            path.lineTo(x,y);
        }
        int speed=Prefs.speed(this);
        long duration=moved?clamp((int)(elapsed*speed/100f),35,700):clamp((int)(elapsed*speed/100f),35,250);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path,0,duration);
        GestureDescription.Builder builder=new GestureDescription.Builder().addStroke(stroke);
        setPassThrough(true);
        main.postDelayed(() -> {
            if (zone==null) {injecting=false;return;}
            boolean ok;
            try {
                ok=dispatchGesture(builder.build(),new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription g) {finishReplay();}
                    @Override public void onCancelled(GestureDescription g) {finishReplay();}
                }, main);
            } catch (Exception e) {ok=false;}
            if(!ok) finishReplay();
            // Safety: restore interaction if a vendor ROM never calls the callback.
            main.postDelayed(() -> {if(injecting) finishReplay();},1800);
        },35);
    }
    private void finishReplay() {
        if (!injecting) return;
        injecting=false;
        main.postDelayed(() -> {
            if (zone!=null && Prefs.active(this)) setPassThrough(false);
        },35);
    }
    private final class ZoneView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final List<PointF> points = new ArrayList<>();
        private boolean moving,resizing,tracking,ignoreMulti;
        private float startRawX,startRawY;
        private int initialX,initialY,initialW,initialH;
        private long downTime;
        ZoneView(){super(TouchService.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            boolean edit=Prefs.editing(TouchService.this);
            int color=Prefs.stroke(TouchService.this);
            int fill=Prefs.alpha(TouchService.this);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor((Math.round(fill*255f/100f)<<24)|(color&0x00ffffff));
            c.drawRoundRect(dp(3),dp(3),getWidth()-dp(3),getHeight()-dp(3),dp(15),dp(15),paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(edit?3:2));
            paint.setColor(color);
            c.drawRoundRect(dp(3),dp(3),getWidth()-dp(3),getHeight()-dp(3),dp(15),dp(15),paint);
            if (edit) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(0xdd8066f3);
                c.drawCircle(getWidth()-dp(16),getHeight()-dp(16),dp(13),paint);
                paint.setColor(Color.WHITE);
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setTypeface(Typeface.DEFAULT_BOLD);
                paint.setTextSize(dp(12));
                c.drawText("ПЕРЕТАЩИТЕ",getWidth()/2f,getHeight()/2f,paint);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (zoneParams==null) return false;
            int action=e.getActionMasked();
            boolean edit=Prefs.editing(TouchService.this);
            if(edit) {
                if(action==MotionEvent.ACTION_DOWN) {
                    startRawX=e.getRawX(); startRawY=e.getRawY();
                    initialX=zoneParams.x;initialY=zoneParams.y;
                    initialW=zoneParams.width;initialH=zoneParams.height;
                    resizing=e.getX()>getWidth()-dp(42)&&e.getY()>getHeight()-dp(42);
                    moving=!resizing;return true;
                }
                if(action==MotionEvent.ACTION_MOVE&&(moving||resizing)) {
                    int dx=Math.round(e.getRawX()-startRawX);
                    int dy=Math.round(e.getRawY()-startRawY);
                    if(resizing) changeBox(initialX,initialY,initialW+dx,initialH+dy);
                    else changeBox(initialX+dx,initialY+dy,initialW,initialH);
                    return true;
                }
                if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL) {
                    moving=false;resizing=false;return true;
                }
                return true;
            }
            if (injecting) return true;
            if(action==MotionEvent.ACTION_DOWN) {
                points.clear();ignoreMulti=false;tracking=true;downTime=e.getEventTime();
                points.add(new PointF(e.getRawX(),e.getRawY())); return true;
            }
            if(action==MotionEvent.ACTION_POINTER_DOWN) { ignoreMulti=true;points.clear(); return true; }
            if(action==MotionEvent.ACTION_MOVE&&tracking&&!ignoreMulti) {
                PointF p=new PointF(e.getRawX(),e.getRawY());
                if (points.size()<180) points.add(p);
                return true;
            }
            if(action==MotionEvent.ACTION_CANCEL) { tracking=false;points.clear();return true; }
            if(action==MotionEvent.ACTION_UP) {
                if (tracking&&!ignoreMulti) {
                    points.add(new PointF(e.getRawX(),e.getRawY()));
                    List<PointF> copy=new ArrayList<>(points);
                    injecting=true;
                    replay(copy,Math.max(1,e.getEventTime()-downTime));
                }
                tracking=false;points.clear();return true;
            }
            return true;
        }
    }
}
