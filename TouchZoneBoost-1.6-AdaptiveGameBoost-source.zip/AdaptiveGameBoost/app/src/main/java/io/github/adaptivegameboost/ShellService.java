package io.github.adaptivegameboost;

import android.os.Process;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/** Shizuku UserService: runs as adb/shell, never as the application UID. */
public final class ShellService extends IShell.Stub {
    public ShellService() {}
    public ShellService(android.content.Context ignored) {}

    @Override public String execute(String command) {
        if (Process.myUid() != 2000 && Process.myUid() != 0)
            return "exit=126\nОтсутствует UID shell. Запусти Shizuku через ADB.";
        // Only our app constructs commands; do not accept arbitrary text from UI or intents.
        java.lang.Process process = null;
        try {
            ProcessBuilder builder = new ProcessBuilder("/system/bin/sh", "-c", command);
            builder.redirectErrorStream(true);
            process = builder.start();
            StringBuilder result = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
            char[] buffer = new char[1024];
            int count;
            while ((count = reader.read(buffer)) >= 0) {
                if (result.length() < 12000) result.append(buffer, 0, Math.min(count, 12000 - result.length()));
            }
            if (!process.waitFor(15, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return "exit=124\nПревышено время выполнения команды";
            }
            return "exit=" + process.exitValue() + "\n" + result;
        } catch (Exception e) {
            return "exit=125\n" + e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (process != null) process.destroy();
        }
    }
}
