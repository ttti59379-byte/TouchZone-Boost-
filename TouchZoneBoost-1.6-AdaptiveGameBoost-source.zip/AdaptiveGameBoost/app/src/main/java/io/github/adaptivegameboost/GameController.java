package io.github.adaptivegameboost;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.PowerManager;
import java.util.Locale;
import java.util.function.Consumer;

/** System Game Mode and downscale interventions, not NVIDIA DLSS. */
public final class GameController {
    public static final String FREE_FIRE="com.dts.freefireth";
    public static final String FREE_FIRE_MAX="com.dts.freefiremax";
    private static final String PREFS="adaptive_boost_v1";
    public static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    public static String game(Context c){return prefs(c).getBoolean("max",false)?FREE_FIRE_MAX:FREE_FIRE;}
    public static String packageName(String pkg){
        if(!FREE_FIRE.equals(pkg) && !FREE_FIRE_MAX.equals(pkg))
            throw new IllegalArgumentException("Unsupported package");
        return pkg;
    }
    public static int profile(Context c){return prefs(c).getInt("profile",0);}
    public static int thermal(Context c) {
        PowerManager pm=(PowerManager)c.getSystemService(Context.POWER_SERVICE);
        if(pm==null)return -1;
        try{return pm.getCurrentThermalStatus();}catch(Throwable e){return -1;}
    }
    public static String thermalLabel(Context c){
        switch(thermal(c)) {
            case 0:return "Норма";
            case 1:return "Небольшой нагрев";
            case 2:return "Умеренный нагрев";
            case 3:return "Сильный нагрев";
            case 4:return "Критический нагрев";
            case 5:return "Аварийная температура";
            case 6:return "Выключение из-за нагрева";
            default:return "Неизвестно";
        }
    }
    public static String scaling(Context c){
        int p=profile(c);
        switch(p) {
            case 1:return "0.90";
            case 2:return "0.85";
            case 3:return "0.75";
            case 4:return "disable";
            case 5:return String.format(Locale.US,"%.2f",Math.max(70,Math.min(90,prefs(c).getInt("manual",85)))/100.0);
            default:
                int t=thermal(c);
                // Thermal awareness at launch only. A live game restart is needed for scale changes.
                if(t>=3)return "0.75";
                if(t==2)return "0.80";
                if(t==1)return "0.85";
                return "0.90";
        }
    }
    public static void apply(Context c, String pkg, Consumer<String> cb){
        final String packageId=packageName(pkg);
        final Context app=c.getApplicationContext();
        final String factor=scaling(app);
        if("disable".equals(factor)){
            ShizukuBridge.run(app,"cmd game mode performance "+packageId+"; echo '--- режим ---'; cmd game list-modes "+packageId,
              out-> cb.accept("Режим производительности (без изменения масштабирования):\n"+out));
            return;
        }
        SharedPreferences pref=prefs(app);
        final String key="saved_overlay_"+packageId;
        if(pref.contains(key)){
            applyWithBackup(app,packageId,factor,cb);return;
        }
        // Preserve the user's game_overlay entry before first modification.
        ShizukuBridge.run(app,"device_config get game_overlay "+packageId, result -> {
            if(!result.startsWith("exit=0\n")) {
                cb.accept("Не удалось сохранить исходные настройки; изменения не применены:\n"+result);
                return;
            }
            String old=result.substring(result.indexOf('\n')+1).trim();
            if(!(old.equals("null") || old.matches("[A-Za-z0-9_,:.=+-]{1,1000}"))){
                cb.accept("Неожиданный формат исходной настройки, изменения отменены: "+old);
                return;
            }
            pref.edit().putString(key,old).apply();
            applyWithBackup(app,packageId,factor,cb);
        });
    }
    private static void applyWithBackup(Context app,String pkg,String factor,Consumer<String> cb){
        // Android Game Mode 2 = performance. OEM can ignore the downscale overlay.
        String config="mode=2,downscaleFactor="+factor;
        String command="device_config put game_overlay "+pkg+" '"+config+"'"+
            " && cmd game mode performance "+pkg+
            " && echo '--- текущие режимы ---' && cmd game list-modes "+pkg+
            " && echo '--- конфигурация ---' && cmd game list-configs "+pkg+
            " && echo '--- overlay ---' && device_config get game_overlay "+pkg;
        ShizukuBridge.run(app,command,result->cb.accept("Профиль (масштаб "+factor+"):\n"+result+
            "\nДля уменьшения рендеринга игру обычно нужно перезапустить. Показатель FPS не гарантируется."));
    }
    public static void reset(Context c, String pkg, Consumer<String> cb){
        final String game=packageName(pkg);
        final SharedPreferences p=prefs(c);
        final String key="saved_overlay_"+game;
        String old=p.getString(key,null);
        String command;
        if(old==null) {
            // Never delete an overlay without a stored backup.
            command="cmd game mode standard "+game;
        } else if("null".equals(old)) {
            command="device_config delete game_overlay "+game+" && cmd game mode standard "+game;
        } else if(old.matches("[A-Za-z0-9_,:.=+-]{1,1000}")) {
            command="device_config put game_overlay "+game+" '"+old+"' && cmd game mode standard "+game;
        } else {cb.accept("Исходные настройки повреждены — сброс отменён");return;}
        ShizukuBridge.run(c,command,result->{
            if(result.startsWith("exit=0\n"))p.edit().remove(key).apply();
            cb.accept("Сброс к стандартному игровому режиму и восстановление game_overlay:\n"+result);
        });
    }
    public static void diagnostics(Context c,String pkg, Consumer<String> cb){
        String game=packageName(pkg);
        ShizukuBridge.run(c,"cmd game list-modes "+game+"; echo ---; cmd game list-configs "+game+"; echo ---; device_config get game_overlay "+game,cb);
    }
    private GameController(){}
}
