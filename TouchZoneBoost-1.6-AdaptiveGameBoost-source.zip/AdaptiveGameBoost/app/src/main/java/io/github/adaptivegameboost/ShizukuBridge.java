package io.github.adaptivegameboost;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import rikka.shizuku.Shizuku;

public final class ShizukuBridge {
    private static volatile IShell service;
    private static volatile boolean binding;
    private static final Handler main = new Handler(Looper.getMainLooper());
    private static final ExecutorService worker = Executors.newSingleThreadExecutor();
    private static final ArrayList<Request> queue = new ArrayList<>();
    private static Context context;
    private static boolean binderListenerAdded;
    private static final class Request {
        String command;
        Consumer<String> callback;
        Request(String c, Consumer<String> cb) { command=c; callback=cb; }
    }
    private static final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            synchronized (ShizukuBridge.class) { service=IShell.Stub.asInterface(binder); binding=false; }
            drain();
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            synchronized (ShizukuBridge.class) { service=null; binding=false; }
        }
    };
    public static synchronized void init(Context c) {
        if(c==null) return;
        context=c.getApplicationContext();
        if(!binderListenerAdded) {
            Shizuku.addBinderReceivedListener(() -> connect(context));
            Shizuku.addBinderDeadListener(() -> {
                synchronized (ShizukuBridge.class) { service=null; binding=false; }
                failQueued("Shizuku отключился");
            });
            binderListenerAdded=true;
        }
    }
    public static boolean allowed() {
        try { return Shizuku.pingBinder() && Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED; }
        catch(Throwable e) { return false; }
    }
    public static synchronized void connect(Context c) {
        if(c==null) return;
        init(c);
        if(service!=null) { drain(); return; }
        if(binding || !allowed()) return;
        try {
            binding=true;
            Shizuku.UserServiceArgs args=new Shizuku.UserServiceArgs(
                new ComponentName(c.getPackageName(),ShellService.class.getName()))
                .daemon(false).processNameSuffix("game_shell").version(1);
            Shizuku.bindUserService(args,connection);
        } catch (Throwable e) {
            binding=false;
            failQueued("Ошибка Shizuku: " + e.getMessage());
        }
    }
    public static void run(Context c,String command,Consumer<String> cb) {
        init(c);
        if(!allowed()) {
            main.post(() -> {if(cb!=null) cb.accept("exit=126\nЗапусти Shizuku и предоставь разрешение");});
            return;
        }
        synchronized (ShizukuBridge.class) {queue.add(new Request(command,cb));}
        connect(c);
        drain();
    }
    private static void drain() {
        final ArrayList<Request> batch;
        final IShell current;
        synchronized (ShizukuBridge.class) {
            current=service;
            if(current==null || queue.isEmpty()) return;
            batch=new ArrayList<>(queue); queue.clear();
        }
        for(Request req:batch) {
            worker.execute(() -> {
                String result;
                try { result=current.execute(req.command); }
                catch(Throwable e) { result="exit=125\nСвязь со службой: "+e.getMessage(); }
                String response=result;
                if(req.callback!=null) main.post(() -> req.callback.accept(response));
            });
        }
    }
    private static void failQueued(String reason) {
        final ArrayList<Request> batch;
        synchronized (ShizukuBridge.class){batch=new ArrayList<>(queue);queue.clear();}
        for(Request req:batch) if(req.callback!=null) main.post(() -> req.callback.accept("exit=126\n"+reason));
    }
    private ShizukuBridge() {}
}
