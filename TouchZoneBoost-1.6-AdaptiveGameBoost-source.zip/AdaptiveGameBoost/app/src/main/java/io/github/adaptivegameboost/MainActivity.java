package io.github.adaptivegameboost;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import rikka.shizuku.Shizuku;

public final class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status, thermal, info, diagnostic, selection;
    private RadioGroup profiles;
    private final int white=0xfff3f0ff, secondary=0xffb7b4c7, accent=0xffa99aff;
    private final String[] choices={
        "Адаптивный — учитывает нагрев перед запуском",
        "Качество — рендеринг 90%",
        "Баланс — рендеринг 85%",
        "FPS — рендеринг 75%",
        "Системный Performance — без изменения масштаба",
        "Ручной — масштаб ниже"
    };
    private final Shizuku.OnRequestPermissionResultListener onPermission=(requestCode,grantResult)->
        runOnUiThread(()->{ShizukuBridge.connect(this);refresh();});

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff10111a);
        getWindow().setNavigationBarColor(0xff10111a);
        ShizukuBridge.init(this);
        try{Shizuku.addRequestPermissionResultListener(onPermission);}catch(Throwable ignored){}
        buildUi();
    }
    private int dp(int px){return Math.round(getResources().getDisplayMetrics().density*px);}
    private GradientDrawable bg(int color,int radius){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;
    }
    private TextView text(String value,int size,int color){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        t.setPadding(0,dp(7),0,dp(7));return t;
    }
    private void add(TextView t){root.addView(t);}
    private Button button(String label,int color){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(15);
        b.setTextColor(Color.WHITE);b.setBackground(bg(color,12));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));
        lp.setMargins(0,dp(5),0,dp(5));root.addView(b,lp);
        return b;
    }
    private void buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(0xff10111a);scroll.setFillViewport(true);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20),dp(18),dp(20),dp(34));scroll.addView(root);setContentView(scroll);
        TextView title=text("Adaptive Game Boost",26,white);title.setTypeface(null,Typeface.BOLD);add(title);
        add(text("Оптимизация игр через Shizuku — не NVIDIA DLSS",13,secondary));
        status=text("",14,accent);add(status);
        thermal=text("",14,secondary);add(thermal);
        Button shizuku=button("1. Подключить Shizuku",0xff51418c);
        shizuku.setOnClickListener(v->{
            try {
                if(!Shizuku.pingBinder()){
                    diagnostic.setText("Сначала запусти Shizuku через беспроводную отладку.");return;
                }
                if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED){
                    Shizuku.requestPermission(201);
                }else ShizukuBridge.connect(this);
                refresh();
            }catch(Throwable e){diagnostic.setText("Shizuku: "+e.getMessage());}
        });
        add(text("Игра",20,accent));
        RadioGroup games=new RadioGroup(this);
        String[] gameLabels={"Free Fire", "Free Fire MAX"};
        for(int i=0;i<2;i++){
            RadioButton rb=new RadioButton(this);rb.setId(400+i);rb.setText(gameLabels[i]);
            rb.setTextColor(white);rb.setTextSize(15);games.addView(rb);
        }
        games.check(GameController.prefs(this).getBoolean("max",false)?401:400);
        games.setOnCheckedChangeListener((g,id)->{GameController.prefs(this).edit().putBoolean("max",id==401).apply();refresh();});
        root.addView(games);
        add(text("Профиль",20,accent));
        profiles=new RadioGroup(this);profiles.setOrientation(LinearLayout.VERTICAL);
        for(int i=0;i<choices.length;i++){
            RadioButton b=new RadioButton(this);b.setId(500+i);b.setText(choices[i]);
            b.setTextColor(white);b.setTextSize(14);b.setPadding(dp(2),dp(6),0,dp(6));profiles.addView(b);
        }
        profiles.check(500+GameController.profile(this));
        profiles.setOnCheckedChangeListener((g,id)->{
            if(id<500||id>=506)return;
            GameController.prefs(this).edit().putInt("profile",id-500).apply();refresh();
        });
        root.addView(profiles);
        selection=text("",14,secondary);add(selection);
        final TextView sliderLabel=text("",14,secondary);add(sliderLabel);
        SeekBar manual=new SeekBar(this);manual.setMax(4);manual.setProgress((GameController.prefs(this).getInt("manual",85)-70)/5);
        root.addView(manual);
        manual.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar b,int progress,boolean fromUser){
                int factor=70+progress*5;
                sliderLabel.setText("Ручной масштаб: "+factor+"% (используется профиль «Ручной»)");
                if(fromUser){GameController.prefs(MainActivity.this).edit().putInt("manual",factor).apply();refresh();}
            }
            @Override public void onStartTrackingTouch(SeekBar b){}
            @Override public void onStopTrackingTouch(SeekBar b){}
        });
        sliderLabel.setText("Ручной масштаб: "+(70+manual.getProgress()*5)+"% (используется профиль «Ручной»)");
        CheckBox auto=new CheckBox(this);
        auto.setText("Автоматически применять профиль при открытии игры");
        auto.setTextColor(white);auto.setTextSize(14);
        auto.setChecked(GameController.prefs(this).getBoolean("auto",false));
        root.addView(auto);
        auto.setOnCheckedChangeListener((v,checked)->{
            GameController.prefs(this).edit().putBoolean("auto",checked).apply();
            if(checked)new AlertDialog.Builder(this).setTitle("Автоматическое включение")
                .setMessage("Чтобы приложение замечало запуск Free Fire, включи его службу в специальных возможностях. Она отслеживает только открытие приложений и не перехватывает касания. Для нового масштаба может понадобиться перезапуск игры.")
                .setPositiveButton("Открыть настройки",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                .setNegativeButton("Позже",null).show();
        });
        Button apply=button("2. Применить профиль",0xff5443a0);
        apply.setOnClickListener(v->apply(false));
        Button start=button("▶ Применить и запустить Free Fire",0xffbd592f);
        start.setOnClickListener(v->apply(true));
        Button diagnosis=button("Проверить доступные игровые режимы",0xff2c3747);
        diagnosis.setOnClickListener(v-> GameController.diagnostics(this,GameController.game(this),this::showResult));
        Button reset=button("Вернуть стандартные настройки",0xff513642);
        reset.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Сброс?")
            .setMessage("Вернуть ранее сохранённый game_overlay и стандартный режим выбранной игры? Все остальные игры не затрагиваются.")
            .setPositiveButton("Сбросить",(d,w)->GameController.reset(this,GameController.game(this),this::showResult))
            .setNegativeButton("Отмена",null).show());
        info=text("Это не генератор кадров. Уменьшение рендеринга может повысить FPS только там, где игра ограничена GPU. Масштабирование может игнорироваться HyperOS или игрой. Для применения масштаба перезапусти игру.",13,secondary);
        add(info);
        diagnostic=text("Результат диагностики появится здесь.",13,white);diagnostic.setTextIsSelectable(true);add(diagnostic);
        refresh();
    }
    private void apply(boolean launch){
        final String chosen=GameController.game(this);
        diagnostic.setText("Применяю профиль... Проверь, что Shizuku запущен и разрешён.");
        GameController.apply(this,chosen,result->{
            showResult(result);
            if(launch){
                if(result.contains("exit=0\n"))openGame(chosen);
                else new AlertDialog.Builder(this).setTitle("Профиль не применён")
                    .setMessage("Открыть игру с обычными настройками?\n\n"+result)
                    .setPositiveButton("Открыть",(d,w)->openGame(chosen))
                    .setNegativeButton("Отмена",null).show();
            }
        });
    }
    private void openGame(String pkg){
        Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);
        if(launch==null){diagnostic.setText("Не найдена игра: "+pkg);return;}
        try{startActivity(launch);}catch(Throwable t){diagnostic.setText("Не удалось открыть: "+t.getMessage());}
    }
    private void showResult(String s){diagnostic.setText(s);refresh();}
    private void refresh(){
        if(status==null)return;
        status.setText(ShizukuBridge.allowed()?"Shizuku: доступ разрешён":"Shizuku: нет подключения или разрешения");
        thermal.setText("Нагрев системы: "+GameController.thermalLabel(this));
        selection.setText("Выбранный масштаб: "+("disable".equals(GameController.scaling(this))?"100%, без вмешательства":GameController.scaling(this)));
        if(diagnostic!=null && diagnostic.getText().toString().equals("Результат диагностики появится здесь.")){
            String prev=GameController.prefs(this).getString("last_result","");
            if(!prev.isEmpty())diagnostic.setText("Результат автозапуска:\n"+prev);
        }
    }
    @Override protected void onResume(){super.onResume();refresh();}
    @Override protected void onDestroy(){
        try{Shizuku.removeRequestPermissionResultListener(onPermission);}catch(Throwable ignored){}
        super.onDestroy();
    }
}
