package io.github.adaptivegameboost;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.os.SystemClock;

/** Optional auto activation on opening Free Fire; no touch capture or overlay. */
public final class GameDetectService extends AccessibilityService {
    private long lastApplied=0;
    private String lastGame="";
    @Override protected void onServiceConnected(){ShizukuBridge.init(this);ShizukuBridge.connect(this);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event.getEventType()!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)return;
        if(event.getPackageName()==null)return;
        String opened=event.getPackageName().toString();
        if(!opened.equals(GameController.FREE_FIRE) && !opened.equals(GameController.FREE_FIRE_MAX)){
            if(!opened.equals("com.android.systemui"))lastGame="";
            return;
        }
        if(!GameController.prefs(this).getBoolean("auto",false))return;
        if(!opened.equals(GameController.game(this)))return;
        long now=SystemClock.elapsedRealtime();
        if(opened.equals(lastGame) && now-lastApplied<30000)return;
        lastGame=opened;lastApplied=now;
        GameController.apply(this,opened,result->
            GameController.prefs(this).edit().putString("last_result",result).apply());
    }
    @Override public void onInterrupt(){}
}
