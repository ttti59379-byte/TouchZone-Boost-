package io.github.adaptivegameboost;
interface IShell { String execute(String command); }
